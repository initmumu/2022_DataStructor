#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;

void get_command(/*작성할 것*/);
void get_size(/*작성할 것*/);
int** gen_matrix(/*작성할 것*/);
void swap(int* a, int* b);// 주어짐
void sort_array(int* ary, int size);
void sort_matrix_row(/*작성할 것*/);
void print_matrix(/*작성할 것*/);
void save_matrix(/*작성할 것*/);
void free_matrix(/*작성할 것*/);

int main() {
    string command;
    int** matrix = NULL;
    int size = 0;

    while (1) {
        get_command(command);
        if(command == "1"){
            get_size(size);
            matrix = gen_matrix(size);
        }

        else if (command == "2") {
            print_matrix(matrix, size);
        }

        else if (command == "3") {
            sort_matrix_row(matrix, size);
        }
        else if (command == "4") {
            save_matrix(matrix, size);
        }
        else if (command == "0") {
            free_matrix(matrix, size);
            cout << "Exit the program.." << endl;
            exit(104);
        }
        else {
            cout << "Wrong command" << endl << endl;
        }
    }  
    return 0;
}

void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void sort_array(int* ary, int size){
// 보너스 문제를 안 풀시에는 작성하지 않아도 됨
}
